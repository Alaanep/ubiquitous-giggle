﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EX5
{
    public partial class Form1 : Form
    {
        Random random = new Random();
        public Form1()
        {
            InitializeComponent();
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {   
            
            int xCoordinate = random.Next(0,this.ClientSize.Width-button1.Width);
            int yCoordinate = random.Next(0, this.ClientSize.Height- button1.Height);
            button1.Left = xCoordinate;
            button1.Top = yCoordinate;
            
            
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            button1.Text = "Click me start again";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
            timer1.Interval = 700;

        }
    }
}
