﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EX1
{
    public partial class Form1 : Form
    {
        int counter = 0;
        bool isClicked = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void button_minuButton_Click(object sender, EventArgs e)
        {   
            counter++;
            label_CountClicks.Visible = true;
            label_CountClicks.Text = $"I have been clicked {counter} times";
            if(counter > 5)
            {
                label_Wow.Text = $"Wow. Button is clicked {counter} times";
                label_Wow.Visible = true;
            } else
            {
                label_Wow.Visible = false;
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void label_Wow_Click(object sender, EventArgs e)
        {
            counter = 0;
            label_CountClicks.Text = $"Counter reset to {counter}";
            label_Wow.Visible = false;
        }

        private void label_CountClicks_Click(object sender, EventArgs e)
        {
            counter = 0;
            label_CountClicks.Text = $"Counter reset to {counter}";
            label_Wow.Visible = false;
        }
    }
}
