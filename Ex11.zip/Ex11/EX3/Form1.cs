﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EX3
{
    public partial class Form1 : Form
    {
        List<int> availableNumbers = new List<int>();
        List<int> usedNumbers = new List<int>();
        int currentNumber = 0;
        

        public Form1()
        {
            InitializeComponent();
        }

        private void button_Start_Click(object sender, EventArgs e)
        {
            GenerateAvailableNumbers();
            timer1.Start();
        }

        private void GenerateAvailableNumbers()
        {
            int amountOfNumbers = 0;
            int maxNumberToGenerate = 0;
            Random random = new Random();
            try
            {
                amountOfNumbers = int.Parse(textBox_AmountOfNumbers.Text.ToString());
            } catch(Exception ex)
            {
                textBox_AmountOfNumbers.Text = "invalid value. Amount defaulted to 5";
                amountOfNumbers = 5;
            }
            
            try
            {
                maxNumberToGenerate = int.Parse(textBox_MaxNumber.Text.ToString());
            }
            catch(Exception ex)
            {
                textBox_MaxNumber.Text = "invalid value. Max number defaulted to 5";
                maxNumberToGenerate = 5;
            }
            

            for(int i = 0; i<amountOfNumbers; i++)
            {
                int numberToAdd = random.Next(0, maxNumberToGenerate + 1);
                availableNumbers.Add(numberToAdd);
            }
        }

        private string ConvertListToString( List <int> numbers)
        {
            int counter = 0;

            string result = string.Empty;
            for (int i = 0; i < numbers.Count; i++){
                counter++;
                
                result += $"{numbers[i]}, ";
                if (counter % 4 == 0 )
                {
                    result += "\n";
                }
            }
            return result;
        }

        private void DrawNextNumber()
        {
            if (availableNumbers.Count != 0)
            {
                Random random = new Random();
                int idx = random.Next(0, availableNumbers.Count);
                currentNumber = availableNumbers[idx];
                availableNumbers.RemoveAt(idx);
                usedNumbers.Add(currentNumber);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (availableNumbers.Count != 0)
            {
                button_Start.Enabled = false;
                DrawNextNumber();
                label_AvailableNumbers.Text = ConvertListToString(availableNumbers);
                label_Results.Text = ConvertListToString(usedNumbers);
                label_CurrentNumber.Text = currentNumber.ToString();
                button_Start.Text = "Game is on";

            } else
            {
                label_CurrentNumber.Text = "Finished";
                button_Start.Text = "Try Again!";
                button_Start.Enabled = true;
            }
            
        }
    }
}
